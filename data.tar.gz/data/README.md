# 20 Newsgroups
Source: http://qwone.com/~jason/20Newsgroups/

# WebKB
Source: [Ana Cardoso-Cachopo, Improving Methods for Single-label Text Categorization](http://web.ist.utl.pt/~acardoso/datasets/)

# R8 (Reuters 21578)
Source: [Ana Cardoso-Cachopo, Improving Methods for Single-label Text Categorization](http://web.ist.utl.pt/~acardoso/datasets/)